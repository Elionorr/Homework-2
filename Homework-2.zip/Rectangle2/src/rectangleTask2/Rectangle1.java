package rectangleTask2;

public class Rectangle1 {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public double getWidth() {
		return this.a;
	}
	
	public void setHeight(double b) {
		this.b = b;
	}

	public double getHeight() {
		return this.b;
	}
	public static void main(String[] args) {
	
		Rectangle1 rectangle = new Rectangle1();
		rectangle = null;
		System.out.println(rectangle.getHeight()); // Exception in thread "main" java.lang.NullPointerException
	}

}