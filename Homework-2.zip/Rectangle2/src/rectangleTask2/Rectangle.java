package rectangleTask2;

public class Rectangle {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}

	
	public static void main(String[] args) {
	
		Rectangle rectangle;
		System.out.println(rectangle); //The local variable rectangle may not have been initialized
	}

}
