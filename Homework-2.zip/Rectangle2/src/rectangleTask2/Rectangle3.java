package rectangleTask2;

public class Rectangle3 {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public double getWidth() {
		return this.a;
	}
	
	public void setHeight(double b) {
		this.b = b;
	}

	public double getHeight() {
		return this.b;
	}
	public static void main(String[] args) {
	
		Rectangle3 rectangle = new Rectangle3();
		Rectangle3 rect = new Rectangle3();
		
		rectangle.setWidth(4);
		rectangle.setHeight(7);
		
		rect.setWidth(6);
		rect.setHeight(3);
		
		// Shecdoma iqneba im shemtxvevashi tu davwert "rectangle == rect".
		// Tu davwert "rectangle = rect"", mashin shecdomas ar gamoitans.
		
		rectangle = rect;
		rectangle.setWidth(10);
		rectangle.setHeight(5);
		System.out.println(rect.getHeight()); // Dabechdavs 5
		System.out.println(rect.getWidth()); // Dabechdavs 10
	}

}