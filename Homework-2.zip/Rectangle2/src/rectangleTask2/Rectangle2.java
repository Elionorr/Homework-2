package rectangleTask2;

public class Rectangle2 {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public double getWidth() {
		return this.a;
	}
	
	public void setHeight(double b) {
		this.b = b;
	}

	public double getHeight() {
		return this.b;
	}
	public static void main(String[] args) {
	
		Rectangle2 rectangle = new Rectangle2();
		System.out.println(rectangle.getHeight()); // Gamoitana 0.0
	}

}