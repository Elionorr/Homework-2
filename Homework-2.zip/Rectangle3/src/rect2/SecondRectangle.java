package rect2;

public class SecondRectangle {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}
	
	public double computeArea() {
		return this.a * this.b;
	}
	
	public double computePerimeter() {
		return (this.a + this.b)*2;
	}
	
	public static void main(String[] args) {
	
		SecondRectangle rect = new SecondRectangle();
		rect.setWidth(3);
		rect.setHeight(10);
		
		System.out.println("Second rectangle's are  is: " + rect.computeArea());
	}

}
