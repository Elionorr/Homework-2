package rectangleTask3;

import rect2.SecondRectangle;

public class Rectangle {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}
	
	public double computeArea() {
		return this.a * this.b;
	}
	
	public static int compare(Rectangle rectangle, SecondRectangle rect) {
		if(rectangle.computeArea() > rect.computeArea()) {
			return 1;
		}else if(rectangle.computeArea() < rect.computeArea()) {
			return -1;
		}else {
			return 0;
		}
	}
	public static void main(String[] args) {
	
		Rectangle rectangle = new Rectangle();
		SecondRectangle rect = new SecondRectangle();
		rectangle.setWidth(2);
		rectangle.setHeight(6);
		
		rect.setWidth(3);
		rect.setHeight(10);
		
		System.out.println(Rectangle.compare(rectangle, rect));
	}

}
