package rectangle;

public class Rectangle {
	double a;
	double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}
	
	public double computeArea() {
		return this.a * this.b;
	}
	
	public double computePerimeter() {
		return (this.a + this.b)*2;
	}
	
	public static void main(String[] args) {
	
		Rectangle rectangle = new Rectangle();
		rectangle.setWidth(2);
		rectangle.setHeight(6);
		
		System.out.println("Area of this rectangle is: " + rectangle.computeArea());
		System.out.println("Perimeter of this rectangle is: " + rectangle.computePerimeter());
	}

}
