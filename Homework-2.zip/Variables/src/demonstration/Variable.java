package demonstration;

public class Variable {

	public static void main(String[] args) {
		int a;
		int b;
		// int c = a*b;
		/* System.out.println(c); 
		 The local variable a may not have been initialized
		 The local variable b may not have been initialized
		 */
		a = 5;
		b = 10;
		if(a>b) {
			System.out.println("5>10");
		}else {
			System.out.println("5<10");
		}
		// Am shemtxvevashi shecdomas ar gamoitans
		a=5;
		b=1;
	}
}
